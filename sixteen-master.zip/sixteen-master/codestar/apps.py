from django.apps import AppConfig


class CodestarConfig(AppConfig):
    name = 'codestar'
